package com.sts.mini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sts.mini.entity.student;

@Controller
//@RequestMapping("/student")
public class miniController {
	
	
	@GetMapping("/")
	public String home() {
		return "index";
	}
	
	@GetMapping("/add")
	public String add() {
		return "addstu";
	}
	
	@PostMapping("/register")
	public String register(@ModelAttribute student s)
	{
		System.out.println(s);
		return "addstu";
	}
}
