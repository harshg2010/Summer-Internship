package com.sts.mini;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniApplicationTests {

	@Test
	void contextLoads() {
	}

}
