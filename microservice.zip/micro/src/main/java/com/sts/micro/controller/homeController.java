package com.sts.micro.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sts.micro.entity.country;

@RestController
public class homeController {
//	@GetMapping("/country")
//	public List<country> getAllCountries(){
//		List<country> countries=new ArrayList<country>();
//		countries.add(new country("India","Delhi"));
//		countries.add(new country("USA","WDC"));
//		return countries;
//	}
}
