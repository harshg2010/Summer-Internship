package com.spring.orm.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.jvnet.fastinfoset.VocabularyApplicationData;
import org.springframework.orm.hibernate5.HibernateTemplate;

import com.spring.orm.entity.client;
import lombok.*;
import com.spring.orm.entity.client;
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class clientDao{
	
	private HibernateTemplate ht;
	
	@Transactional
	public void insert(client c) {
		ht.save(c);
		System.out.println("Record inserted");
	}
	
	public client select(int id) {
		client c=ht.get(client.class, id);
		return c;
	}
	
	public List<client> selectAll()
	{
		List<client> cs=ht.loadAll(client.class);
		return cs;
	}
	@Transactional
	public void delete(int id) {
		client c=ht.get(client.class, id);
		ht.delete(c);
		System.out.println("Record deleted.");
	}
	@Transactional
	public void update(client c) {
		ht.update(c);
		System.out.println("Record updated.");
	}
}