package com.spring.orm;

import java.util.List;

import javax.management.loading.PrivateClassLoader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.dao.clientDao;
import com.spring.orm.entity.client;
import java.util.Scanner;
public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context=new ClassPathXmlApplicationContext("com/spring/orm/config1.xml");
       clientDao c=context.getBean("cDao",clientDao.class);
       System.out.println("........................Welcome to DATABASE...........................");
       Scanner scanner=new Scanner(System.in);
       System.out.println("Enter choice: 1 for insert, 2 for select, 3 for select all, 4 for update, 5 for delete: ");
       int choice=scanner.nextInt();
       switch(choice) {
    	   case 1:
    		   System.out.println("Enter id: ");
    		   int id=scanner.nextInt();
    		   System.out.println("Enter name:");
    		   String name=scanner.next();
    		   client c1=new client(id,name);
    		   c.insert(c1);
    		   break;
    	   case 2:
    		   System.out.println("Enter id to select: ");
    		   int id1=scanner.nextInt();
    		   client cs=c.select(id1);
    		   System.out.println("ID: "+cs.getId()+" Name: "+cs.getName());
    		   break;
    	   case 3:
    		   List<client> css=c.selectAll();
    		   for(client ci: css)
    		   {
    			   System.out.println("ID: "+ci.getId()+" Name: "+ci.getName());
    		   }
    		   break;
    	   case 4:
    		   System.out.println("Enter id to update: ");
    		   int id2=scanner.nextInt();
    		   System.out.println("Enter name to update: ");
    		   String name1=scanner.next();
    		   client c2=new client(id2,name1);
    		   c.update(c2);
    		   break;
       
    	   case 5:
    		   System.out.println("Enter id to delete: ");
    		   int id3=scanner.nextInt();
    		   c.delete(id3);
    		   break;
    }
    }      
}
