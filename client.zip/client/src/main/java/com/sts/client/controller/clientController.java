package com.sts.client.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.sts.client.entity.country;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
public class clientController {
	
	@Autowired
	private DiscoveryClient discoveryClient;
	
	@SuppressWarnings("unchecked")
	@GetMapping("/")
	public List<country> getCountry(){
		List<ServiceInstance> instances =discoveryClient.getInstances("Country-Service");
		if(instances!=null && !instances.isEmpty())
		{
			ServiceInstance serviceInstance=(ServiceInstance) instances.get(0);
			String url = serviceInstance.getUri().toString();
			url = url + "/country";
			 RestTemplate restTemplate = new RestTemplate();
			 return restTemplate.getForObject(url, List.class);
		}
		  return null;
	}
}
